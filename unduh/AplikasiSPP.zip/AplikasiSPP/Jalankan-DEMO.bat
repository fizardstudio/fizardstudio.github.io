@echo off
rem Menjalankan aplikasi dengan data contoh (30 siswa). Data asli sekolah tidak tersentuh.
"%~dp0AplikasiSPP.exe" -data "%~dp0contoh-data" -port 8090
pause
