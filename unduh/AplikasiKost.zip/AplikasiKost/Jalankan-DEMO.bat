@echo off
rem Menjalankan aplikasi dengan data contoh (20 kamar, 17 penghuni). Data asli kost tidak tersentuh.
"%~dp0AplikasiKost.exe" -data "%~dp0contoh-data" -port 8090
pause
